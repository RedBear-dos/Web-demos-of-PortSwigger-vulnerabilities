<?php

// Hiển thị lỗi (debug khi dev)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Định nghĩa mảng sản phẩm
$products = [
    1 => 'Laptop Dell',
    2 => 'Điện thoại iPhone'
];

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang kiểm tra sản phẩm và ảnh</title>
</head>
<body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">

    <h1>Chào mừng đến với trang kiểm tra!</h1>

    <!-- Hai nút chức năng -->
    <button onclick="window.location.href='?action=product'">Kiểm tra sản phẩm</button>
    <button onclick="window.location.href='?action=image'">Xem hình ảnh</button>

    <hr style="margin: 30px 0;">

    <?php
    // Nếu chọn chức năng product
    if (isset($_GET['action']) && $_GET['action'] === 'product') {
        echo "<h2>Kiểm tra sản phẩm</h2>";
        echo "<p>Chọn ID sản phẩm để kiểm tra:</p>";

        echo '<a href="?productId=1">Sản phẩm 1</a><br>';
        echo '<a href="?productId=2">Sản phẩm 2</a><br>';

    // Nếu chọn chức năng image
    } elseif (isset($_GET['action']) && $_GET['action'] === 'image') {
        echo "<h2>Xem ảnh (có lỗi Path Traversal)</h2>";
        echo '<p>Nhập tên file để xem nội dung:</p>';

        // Form cho người dùng nhập filename
        echo '<form method="GET">';
        echo '<input type="hidden" name="action" value="image">';
        echo '<input type="text" name="filename" placeholder="Ví dụ: 1.jpg hoặc /etc/passwd">';
        echo '<button type="submit">Xem file</button>';
        echo '</form>';
    }

    // Xử lý xem sản phẩm theo productId
    if (isset($_GET['productId'])) {
        $productId = $_GET['productId'];

        echo "<h3>Kết quả kiểm tra sản phẩm</h3>";
        if (array_key_exists($productId, $products)) {
            echo "✅ Sản phẩm tìm thấy: <b>" . htmlspecialchars($products[$productId]) . "</b>";
        } else {
            echo "❌ Không tìm thấy sản phẩm!";
        }
    }

    // Xử lý xem file ảnh (hoặc bất cứ file nào nhập vào)
    if (isset($_GET['filename'])) {

        $filename = $_GET['filename'];
        
        echo "<h3>Nội dung file: <code>" . htmlspecialchars($filename) . "</code></h3>";

        if (file_exists($filename)) {
            echo "<pre style='text-align:left; background-color:#f4f4f4; padding:10px;'>";
            echo htmlspecialchars(file_get_contents($filename));
            echo "</pre>";
        } else {
            echo "❌ Không tìm thấy file!";
        }
    }

    ?>

</body>
</html>
