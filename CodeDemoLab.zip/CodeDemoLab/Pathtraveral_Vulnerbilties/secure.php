<?php

// Hiển thị lỗi (debug khi dev)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Định nghĩa mảng sản phẩm
$products = [
    1 => 'Laptop Dell',
    2 => 'Điện thoại iPhone'
];

// Thư mục lưu trữ hình ảnh an toàn
define('IMAGE_DIR', __DIR__ . '/images/');

// Hàm kiểm tra và lọc file hợp lệ
function getSafeFilename($filename) {
    // Chỉ lấy tên file, loại bỏ đường dẫn
    $basename = basename($filename);

    // Kiểm tra phần mở rộng (chỉ cho phép jpg và png)
    $allowedExtensions = ['jpg', 'jpeg', 'png'];
    $extension = strtolower(pathinfo($basename, PATHINFO_EXTENSION));

    if (!in_array($extension, $allowedExtensions)) {
        return false;
    }

    return $basename;
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Trang kiểm tra sản phẩm và ảnh</title>
</head>
<body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">

    <h1>Chào mừng đến với trang kiểm tra!</h1>

    <!-- Hai nút chức năng -->
    <button onclick="window.location.href='?action=product'">Kiểm tra sản phẩm</button>
    <button onclick="window.location.href='?action=image'">Xem hình ảnh</button>

    <hr style="margin: 30px 0;">

    <?php
    // Nếu chọn chức năng product
    if (isset($_GET['action']) && $_GET['action'] === 'product') {
        echo "<h2>Kiểm tra sản phẩm</h2>";
        echo "<p>Chọn ID sản phẩm để kiểm tra:</p>";

        echo '<a href="?productId=1">Sản phẩm 1</a><br>';
        echo '<a href="?productId=2">Sản phẩm 2</a><br>';

    // Nếu chọn chức năng image
    } elseif (isset($_GET['action']) && $_GET['action'] === 'image') {
        echo "<h2>Xem ảnh an toàn</h2>";
        echo '<p>Nhập tên file ảnh (ví dụ: 1.jpg hoặc 2.png):</p>';

        // Form cho người dùng nhập filename
        echo '<form method="GET">';
        echo '<input type="hidden" name="action" value="image">';
        echo '<input type="text" name="filename" placeholder="Ví dụ: 1.jpg">';
        echo '<button type="submit">Xem ảnh</button>';
        echo '</form>';
    }

    // Xử lý xem sản phẩm theo productId
    if (isset($_GET['productId'])) {
        $productId = $_GET['productId'];

        echo "<h3>Kết quả kiểm tra sản phẩm</h3>";
        if (array_key_exists($productId, $products)) {
            echo "✅ Sản phẩm tìm thấy: <b>" . htmlspecialchars($products[$productId]) . "</b>";
        } else {
            echo "❌ Không tìm thấy sản phẩm!";
        }
    }

    // Xử lý xem file ảnh (đã kiểm soát bảo mật)
    if (isset($_GET['filename'])) {

        $userInput = $_GET['filename'];
        $safeFilename = getSafeFilename($userInput);

        echo "<h3>Yêu cầu xem file: <code>" . htmlspecialchars($userInput) . "</code></h3>";

        if ($safeFilename) {
            $filePath = IMAGE_DIR . $safeFilename;

            if (file_exists($filePath)) {
                echo "<h3>Hiển thị ảnh:</h3>";
                echo "<img src='images/" . htmlspecialchars($safeFilename) . "' style='max-width:500px;'><br>";
                echo "<p>✅ Đã tải ảnh thành công!</p>";
            } else {
                echo "❌ Không tìm thấy file trong thư mục hợp lệ!";
            }
        } else {
            echo "❌ Tên file không hợp lệ! Chỉ cho phép file ảnh .jpg, .jpeg, .png";
        }
    }

    ?>

</body>
</html>
