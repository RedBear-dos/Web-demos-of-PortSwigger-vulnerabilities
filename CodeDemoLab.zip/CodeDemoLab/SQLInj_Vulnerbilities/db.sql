CREATE TABLE users (
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

INSERT INTO users (username, password) VALUES ('admin', MD5('password'));
INSERT INTO users (username, password) VALUES ('wiener', MD5('peter'));
INSERT INTO users (username, password) VALUES ('carlos', MD5('happy'));
