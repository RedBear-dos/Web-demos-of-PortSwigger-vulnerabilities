<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $stay_logged_in = isset($_POST["stay_logged_in"]);

    // Danh sách tài khoản hợp lệ
    $valid_credentials = [
        "wiener" => "peter",
        "carlos" => "happy"
    ];

    if (isset($valid_credentials[$username]) && $valid_credentials[$username] === $password) {
        $_SESSION["username"] = $username;

        if ($stay_logged_in) {
            $cookie_value = base64_encode("$username:" . md5($password));
            setcookie("stay_logged_in", $cookie_value, time() + (86400 * 30), "/"); 
        }
        header("Location: my-account.php?id=$username");
        exit();
    } else {
        echo "<p class='error'>Invalid login</p>";
    }
}
?>
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="checkbox" name="stay_logged_in"> Stay logged in
        <button type="submit">Login</button>
    </form>
</body>
</html>
