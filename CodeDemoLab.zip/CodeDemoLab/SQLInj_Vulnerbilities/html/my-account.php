<?php
session_start();
$conn = new mysqli("db", "user", "password", "vulnerable_db");

if (!isset($_SESSION["username"]) && isset($_COOKIE["stay_logged_in"])) {
    list($user, $hash) = explode(":", base64_decode($_COOKIE["stay_logged_in"]));
    $result = $conn->query("SELECT * FROM users WHERE username='$user' AND password='$hash'");
    
    if ($result->num_rows > 0) {
        $_SESSION["username"] = $user;
    }
}

if (!isset($_SESSION["username"])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION["username"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Account</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($username); ?></h2>
    <p>Your account is secure.</p>
    <a href="logout.php">Logout</a>
</body>
</html>
