<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cmd = $_POST['cmd'];

    // Chặn dấu `;` nhưng vẫn có lỗ hổng OS Command Injection
    if (strpos($cmd, ';') !== false) {
        die("Blocked!");
    }

    // Thực thi lệnh nhưng không hiển thị output (Blind Injection)
    shell_exec($cmd . " > nul 2>&1 &"); // Windows
    // shell_exec($cmd . " > /dev/null 2>&1 &"); // Linux

    echo "<p>Command executed (No output shown)</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blind OS Command Injection</title>
</head>
<body>
    <h2>Blind OS Command Injection</h2>
    <form method="POST">
        <label for="cmd">Submit email:</label>
        <input type="text" name="cmd" id="cmd">
        <button type="submit">Execute</button>
    </form>
</body>
</html>
