<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: livechat.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="home-container">
        <h2>Welcome</h2>
        <a href="index.php">Login</a> | <a href="livechat.php">Live Chat</a>
    </div>
</body>
</html>
