<?php
session_start();
$messages = 'messages/';
if (!file_exists($messages)) {
    mkdir($messages, 0777, true);
}

// Đặt tên file chat cho user
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = 'guest_' . session_id();
}

// Tạo ID động cho file chat, tăng dần sau mỗi lần tải
if (!isset($_SESSION['chat_id'])) {
    $_SESSION['chat_id'] = 2; // Bắt đầu từ 2
}
$chat_file = $messages . $_SESSION['chat_id'] . ".txt";

// Hàm tạo phản hồi ngẫu nhiên từ consultant // demo tạm về ng consultant 
function getConsultantReply($userMessage) {
    $responses = [
        "Hello, can I help?",
        "That sounds interesting! Tell me more.",
        "Could you clarify what you mean?",
        "I see, what else can I assist you with?",
        "Great! Do you have any other questions?"
    ];
    return $responses[array_rand($responses)];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $userMessage = trim($_POST['message']);
    if (!empty($userMessage)) {
        $consultantReply = getConsultantReply($userMessage);
        
        $chatLog = "You: " . $userMessage . "\n";
        $chatLog .= "Consultant: " . $consultantReply . "\n";
        
        file_put_contents($chat_file, $chatLog, FILE_APPEND);
    }
}

// Đọc nội dung chat
$chatHistory = file_exists($chat_file) ? file_get_contents($chat_file) : "";

// Xử lý tải file
if (isset($_GET['id_download'])) {
    $downloadFile = $messages . basename($_GET['id_download']);
    // gắn giá trị file 1.txt ( cho đóng làm session của carlos , tựa lúc đó carlos vừa download cuộc trò chuyện với consultant )
    if ($downloadFile === $messages . "1.txt") {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="1.txt"');
        echo "Carlos: Hey Consultant, give me account carlos, i have been hacked from my friend, give me the password account\n";
        echo "Consultant: Oh so sorry, this is password of account: 53434534534534";
        exit;
    }
    // nếu file id đã tồn tại , lập tức sẽ tăng lên  khi click download vào lần sau 
    if (file_exists($downloadFile)) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($downloadFile) . '"');
        readfile($downloadFile);
        $_SESSION['chat_id']++; // Tăng ID sau mỗi lần tải xuống
        exit;
    } // nếu kh có số lần tải quy định thì sẽ in ra này 
    else {
        echo "File not found.";
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Live Chat with Consultant</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="chat-container">
        <h2>Live Chat</h2>
        <div class="chat-box">
            <pre><?php echo nl2br(htmlspecialchars($chatHistory)); ?></pre>
        </div>
        <form method="POST">
            <input type="text" name="message" placeholder="Type your message" required>
            <button type="submit">Send</button>
        </form>
        <a href="http://localhost:9090/livechat.php?id_download=<?php echo $_SESSION['chat_id']; ?>.txt">Download Chat History</a>
    </div>
</body>
</html>
