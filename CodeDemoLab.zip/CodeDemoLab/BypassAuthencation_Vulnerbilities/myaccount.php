<?php
session_start();

// Kiểm tra xem session có hợp lệ không
if (!isset($_SESSION['session_id']) || $_GET['session'] !== $_SESSION['session_id']) {
    echo "Invalid session. <a href='social-login.php'>Login again</a>";
    exit();
}

// Hiển thị thông tin người dùng
$user = $_SESSION['user'];
$email = $_SESSION['email'];

echo "<h2>My Account</h2>";
echo "<p>Your username is: <b>$user</b></p>";
echo "<p>Your email is: <b>$email</b></p>";
?>

<a href="index.php">Home</a> | <a href="logout.php">Log out</a>
