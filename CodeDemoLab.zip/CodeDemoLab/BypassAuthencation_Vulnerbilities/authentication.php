<?php
session_start();

// Danh sách tài khoản có sẵn
$users = [
    "wiener" => ["password" => "peter", "email" => "wiener@gmail.com", "token" => "r3eogheighweiorhfgjwoeifhw1"],
    "carlos" => ["password" => "hello", "email" => "carlos@gmail.com", "token" => "37573057bsjkfhwejkrh2kj345h2"]
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        // Tạo session
        $_SESSION['user'] = $username;
        $_SESSION['email'] = $users[$username]['email'];
        $_SESSION['token'] = $users[$username]['token'];
        
        // Chuyển hướng đến trang xác thực OAuth giả lập
        header("Location: authorize.php");
        exit();
    } else {
        echo "Invalid username or password. <a href='social-login.php'>Try again</a>";
    }
}
