<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: social-login.php");
    exit();
}

$user = $_SESSION['user'];
$email = $_SESSION['email'];
$token = $_SESSION['token'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Authorize</title>
</head>
<body>
    <h2>Authorize</h2>
    <p>WeLikeToBlog is requesting access to:</p>
    <ul>
        <li>Profile</li>
        <li>Email</li>
    </ul>

    <p><strong>User:</strong> <?= $user ?></p>
    <p><strong>Email:</strong> <?= $email ?></p>
    <p><strong>Token:</strong> <?= $token ?></p>

    <form method="POST" action="session-handler.php">
        <input type="hidden" name="user" value="<?= $user ?>">
        <input type="hidden" name="email" value="<?= $email ?>">
        <input type="hidden" name="token" value="<?= $token ?>">
        <button type="submit">Continue</button>
    </form>
</body>
</html>
