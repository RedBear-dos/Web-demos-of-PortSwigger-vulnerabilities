<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: social-login.php");
    exit();
}

// Tạo session ID ngẫu nhiên
$_SESSION['session_id'] = bin2hex(random_bytes(16));

// Chuyển hướng về trang tài khoản với session ID
header("Location: myaccount.php?id_user=" . $_SESSION['user'] . "&session=" . $_SESSION['session_id']);
exit();
