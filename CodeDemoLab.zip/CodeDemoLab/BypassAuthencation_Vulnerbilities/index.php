<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>
<body>
    <h2>Welcome to the Website</h2>
    <a href="social-login.php">Login</a>
</body>
</html>
