<!DOCTYPE html>
<html>
<head>
    <title>Home - Vulnerable Website</title>
</head>
<body>
    <h1>News Articles</h1>
    <ul>
        <li><a href="article.php?id=1&category=tech">Bài viết 1 - Công nghệ</a></li>
        <li><a href="article.php?id=2&category=health">Bài viết 2 - Sức khỏe</a></li>
    </ul>
</body>
</html>
