<?php
if (isset($_GET['id']) && isset($_GET['category'])) {
    $id = $_GET['id'];
    $category = htmlspecialchars($_GET['category'], ENT_QUOTES, 'UTF-8'); // Ngăn XSS

    // Chỉ cho phép số nguyên trong id
    if (!ctype_digit($id)) {
        die("<pre>Lỗi: ID không hợp lệ!</pre>");
    }

    $output = "Đang lấy bài viết ID: $id, Danh mục: $category";
    
    echo "<pre>$output</pre>";
} else {
    echo "<pre>Thiếu tham số id hoặc category.</pre>";
}
?>
