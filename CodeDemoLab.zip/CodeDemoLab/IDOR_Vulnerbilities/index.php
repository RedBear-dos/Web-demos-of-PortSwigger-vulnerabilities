<?php
session_start();

$users = [
    'wiener' => ['password' => 'peter', 'api_key' => 'anhdeptrainhat'],
    'carlos' => ['password' => '1111', 'api_key' => 'anhtainangnhat']
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['username'] = $username;
        header("Location: my-account.php?id=$username");
        exit;
    } else {
        echo "Invalid credentials";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
    <form method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>