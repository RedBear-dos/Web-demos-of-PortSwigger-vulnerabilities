<?php
session_start();

$users = [
    'wiener' => ['password' => 'peter', 'api_key' => 'anhdeptrainhat'],
    'carlos' => ['password' => '1111', 'api_key' => 'anhtainangnhat']
];

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
$requested_user = $_GET['id'] ?? $username;

if ($requested_user !== $username && $username !== 'admin') {
    echo "Bạn không có quyền truy cập";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head><title>My Account</title></head>
<body>
    <h1>My Account</h1>
    <p>Your username is: <?= htmlspecialchars($requested_user) ?></p>
    <p>Your API Key is: <?= htmlspecialchars($users[$requested_user]['api_key'] ?? 'N/A') ?></p>
</body>
</html>